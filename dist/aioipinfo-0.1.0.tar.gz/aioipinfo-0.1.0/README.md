# aioipinfo

A simple, async [ipinfo.io](https://ipinfo.io) client.

Exposes an `IPInfoClient` that implements one querying method, `ipinfo`, and includes a CLI client that can be run with `python3 -m aioipinfo`. See the [full docs](https://gormo.com/aioipinfo/) for more details.
